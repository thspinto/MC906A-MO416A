# Configuration

This project uses python 3.x.

Install matplotlib

```bash
pip install matplotlib
```
